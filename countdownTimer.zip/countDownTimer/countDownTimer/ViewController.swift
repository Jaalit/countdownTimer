//
//  ViewController.swift
//  countDownTimer
//
//  Created by Batuhan Yılmaz on 3.08.2023.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var player: AVAudioPlayer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    var nStart = Timer()
    
    @IBOutlet weak var last: UILabel!
    @IBOutlet weak var timer: UILabel!
    @IBOutlet weak var redButton: UIImageView!
    @IBOutlet weak var patlama: UIImageView!
    
    @IBAction func countdownStarter(_ sender: UIButton) {
        nStart.invalidate()
        
        var i = 3
        
        last.text = "LAST"
        
        nStart = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true){ [self]_ in
            if i >= 1{
                timer.text = "\(i) seconds."
                
                playSound(forResource: "F",withExtension: "wav")
                
                i = i - 1
            }
            if i == 0 {
                redButton.image = UIImage(imageLiteralResourceName: "patlama")
                timer.text = "BOOOOOOM"
                playSound(forResource: "bomb", withExtension: "mp3")
                i = i - 1
            }
        }
    }
    
    func playSound(forResource: String, withExtension: String) {
        var url = Bundle.main.url(forResource: forResource, withExtension: withExtension)
        player = try! AVAudioPlayer(contentsOf: url!)
        player.play()
                
    }
    
}

